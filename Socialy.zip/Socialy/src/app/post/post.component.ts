import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { Post } from '../@shared/models/post';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.scss']
})
export class PostComponent implements OnInit, OnDestroy {

  collapsed: boolean;

  @Input() data: Post;
  @Input() data2: Post;
  @Output() onDelete : EventEmitter<String>;

  constructor() { 
    this.onDelete=new EventEmitter();
  }

  ngOnInit(): void {

  }

  ngOnDestroy() {
    //TODO
  }

  delete() {
    const a=this.data._id;
    this.onDelete.emit(a);
  }

}
