import { Component, Input, OnInit } from '@angular/core';

import { POSTS } from '../@shared/mock';
import { Post } from '../@shared/models/post';
import { PostService } from '../@shared/service/post.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  posts: Post[] = POSTS;

  constructor(private postService : PostService ) {   }

  ngOnInit(): void {
    //console.log("posts > ", this.posts);
    this.postService.getFunction().subscribe((listePost: Post[]) => {
      this.posts = listePost;
  })
  }

  addItem(newItem : Post) {
    //this.posts.push(newItem);
    this.postService.postFunction(newItem).subscribe((p: Post) => {
      this.posts.push(p);
    })
  }

  delete(post:string){
    this.posts = this.posts.filter(item => item._id !== post)
    this.postService.deleteFunction(post).subscribe();
  }






}
