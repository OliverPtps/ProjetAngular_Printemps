import { Component, OnInit, Output,EventEmitter } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Post } from '../@shared/models/post';
import { IdGeneratorUtils } from '../@shared/utils/id-generator.utils';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit {

  @Output() onSubmit : EventEmitter<Post>;
  postForm: FormGroup;
  
  constructor() {   
    this.postForm = new FormGroup({
      title: new FormControl(),
      description: new FormControl(),
      link: new FormControl(),
      icon: new FormControl()
    });
    this.onSubmit=new EventEmitter();
}
  ngOnInit(): void {
  }




submitForm() {

    const post:Post={
      title: this.postForm.get('title').value,
      description:this.postForm.get('description').value,
      link:this.postForm.get('link').value,
      icon: this.postForm.get('icon').value
    }
    //console.log(post);
    this.onSubmit.emit(post);
    this.postForm.reset();
}

}
