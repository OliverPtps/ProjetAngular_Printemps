export interface Post {
  _id?: string;
  title: string;
  description?: string;
  link: string;
  icon?: string;
}
