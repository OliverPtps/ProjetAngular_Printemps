import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Post } from '../models/post';
import { IdGeneratorUtils } from '../utils/id-generator.utils';

@Injectable({
  providedIn: 'root'
})

export class PostService {
 
  
  constructor(private http: HttpClient) { 
    
  }

  postFunction(nvPost : Post){
     // Simple POST request with a JSON body and response type <any>
     return this.http.post<Post>('https://crudcrud.com/api/543b221dcab84df4980cc2a2688c4a8c/posts', 
     { 
      title: nvPost.title,
      link: nvPost.link,
      description:nvPost.description,
      icon: null
      })
  }

  getFunction(){
    return this.http.get<Post[]>('https://crudcrud.com/api/543b221dcab84df4980cc2a2688c4a8c/posts')
  }

  deleteFunction(data : String){
    return this.http.get('https://crudcrud.com/api/543b221dcab84df4980cc2a2688c4a8c/posts/'+data)
  }

}

